package com.example.softwarepos.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AddUser {
    private String username;
    private String password;
}
