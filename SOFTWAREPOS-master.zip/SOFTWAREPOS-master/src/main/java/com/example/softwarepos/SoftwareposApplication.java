package com.example.softwarepos;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SoftwareposApplication {

    public static void main(String[] args) {
        SpringApplication.run(SoftwareposApplication.class, args);
    }

}
