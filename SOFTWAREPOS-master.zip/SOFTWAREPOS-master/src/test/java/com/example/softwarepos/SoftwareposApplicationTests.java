package com.example.softwarepos;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SoftwareposApplicationTests {

    @Test
    void contextLoads() {
    }

}
